<?php
// debug($_GET);
// Array
// (
//     [amt] => 30.16
//     [cc] => USD
//     [item_name] => Payment for order #201908303F566E
//     [item_number] => 1
//     [st] => Completed
//     [tx] => 1RV58874R0496114D
// )
if(!empty($_GET)){
	
	$txn_id = $_GET['tx']; // mã giao dịch paypal

	$item_name = $_GET['item_name'];
	$arr = explode('#', $item_name);
	$madonhang = $arr[1];
	
	$payment_status = $_GET['st'];

	if($payment_status=='Completed'){
        echo 'Thanh toán thành công'; 
        unset($_SESSION['cart']);
    }else{
        echo 'Thanh toán thất bại: '.$row['mess_paypal']; 
    }

}else{
	redirect($config_url_home);
}
?>