<?php 
	// thêm vào file config.php
	
	// SANDBOX:
	// $config['paypal']['url'] = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; 
	// $config['paypal']['id'] = 'sb-plru8448626@business.example.com';

	// LIVE:
	// $config['paypal']['url'] = 'https://www.paypal.com/cgi-bin/webscr';

	$config['paypal']['url'] = 'https://www.paypal.com/cgi-bin/webscr';
	$config['paypal']['id'] = 'admin@123flower.vn'; // Business email ID
	$config['paypal']['return'] = $config_url_home.'/paypal-complete'; // trang nhận kết quả trả về từ trang paypal
	$config['paypal']['cancel_return'] = $config_url_home.'/paypal-cancel'; // Khi hủy thanh toán từ trang paypal
	$config['paypal']['notify_url'] = $config_url_home.'/paypal-ipn.php';
	$config['paypal']['use_sandbox'] = false; // Set to false once you're ready to go live
	
?>