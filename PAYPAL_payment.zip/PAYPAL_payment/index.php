<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form action="<?=$config['paypal']['url']?>" method="post" id="form_paypal">
	    <input type="hidden" name="business" value="<?=$config['paypal']['id']?>">
	    <input type="hidden" name="cmd" value="_xclick">
	    <input type="hidden" id="txt_name_paypal" name="item_name" value="">
	    <input type="hidden" name="item_number" value="1">
	    <input type="hidden" id="total_paypal" name="amount" value="">
	    <input type="hidden" name="no_shipping" value="1">
	    <input type="hidden" name="no_note" value="1">
	    <input type="hidden" name="currency_code" value="USD">
	    <input type="hidden" name="cancel_return" value="<?=$config['paypal']['cancel_return']?>">
	    <input type="hidden" name="return" value="<?=$config['paypal']['return']?>">
	    <input type="hidden" name="notify_url" value="<?=$config['paypal']['notify_url']?>">
	</form>
	

	<script type="text/javascript">
		$().ready(function(){
			$("#submit_thanhtoan").click(function() {
				if(check_frm_order(1)){
					$(".loading").fadeIn('fast');
					var httt = $("input[name=httt]:checked").val();
					if(httt==4){
						$.ajax({
							type: "POST",
							url: 'ajax/save_order_paypal.php',
							data: $("#frm_order").serialize(),
							success: function(madonhang) {
								if(madonhang){
									$("#txt_name_paypal").val("Payment for order #"+madonhang);
									let total_price = $("#cart-total").attr('data-price');
									let vnd = $("#cart-total").attr('data-vnd');
									let total_usd = toUSD(total_price/vnd);
									$("#total_paypal").val(total_usd);
									$("#form_paypal").submit();
								}
							}
				        });
					}else{
						$("#frm_order").submit();
					}
				}
				return false;
			});


			function check_frm_order($more=0){

				if($("input#ten").val().length === 0 ) {
			        alert("<?=_nhaphoten?>");
			        $("input#ten").focus();
			        return false;
			    }
			    if($("input#dienthoai").val().length === 0 ) {
			        alert("<?=_nhapdienthoai?>");
			        $("input#dienthoai").focus();
			        return false;
			    }
			    if($("input#email").val().length === 0 || !check_email($("input#email").val())) {
			        alert("<?=_emailnot?>");
			        $("input#email").focus();
			        return false;
			    }

			    if($("input#diachi").val().length === 0 ) {
			        alert("<?=_nhapdiachi?>");
			        $("input#diachi").focus();
			        return false;
			    }
			    if($("select#tinhthanh").val().length === 0 ) {
			        alert("<?=_chontinhthanh?>");
			        $("select#tinhthanh").focus();
			        return false;
			    }
			    if($("select#quanhuyen").val().length === 0 ) {
			        alert("<?=_chonquanhuyen?>");
			        $("select#quanhuyen").focus();
			        return false;
			    }
			    if($('#check_is_me').is(":checked")){
			    	
			    }else{
			    	if($("input#ten_nguoinhan").val().length === 0 ) {
				        alert("<?=_nhaphoten?>");
				        $("input#ten_nguoinhan").focus();
				        return false;
				    }
				    if($("input#dienthoai_nguoinhan").val().length === 0 ) {
				        alert("<?=_nhapdienthoai?>");
				        $("input#dienthoai_nguoinhan").focus();
				        return false;
				    }

				    if($("input#diachi_nguoinhan").val().length === 0 ) {
				        alert("<?=_nhapdiachi?>");
				        $("input#diachi_nguoinhan").focus();
				        return false;
				    }
				    if($("select#tinhthanh_nguoinhan").val().length === 0 ) {
				        alert("<?=_chontinhthanh?>");
				        $("select#tinhthanh_nguoinhan").focus();
				        return false;
				    }
				    if($("select#quanhuyen_nguoinhan").val().length === 0 ) {
				        alert("<?=_chonquanhuyen?>");
				        $("select#quanhuyen_nguoinhan").focus();
				        return false;
				    }
			    }


			    if($("input#thoigian_giaohang").val().length === 0 ) {
			        alert("<?=_chonthoigiangiao?>");
			        $("input#thoigian_giaohang").focus();
			        return false;
			    }

			    if($more==1){
			    	if($('#check_vat').is(":checked")) {
			            if($("input#vat_congty").val().length === 0 ) {
					        alert("<?=_nhapcongty?>");
					        $("input#vat_congty").focus();
					        return false;
					    }
					    if($("input#vat_mst").val().length === 0 ) {
					        alert("<?=_nhapmst?>");
					        $("input#vat_mst").focus();
					        return false;
					    }
					    if($("input#vat_diachi").val().length === 0 ) {
					        alert("<?=_nhapdiachi?>");
					        $("input#vat_diachi").focus();
					        return false;
					    }
			        }   
			    }

				return true;
			}
		})
	</script>
</body>
</html>