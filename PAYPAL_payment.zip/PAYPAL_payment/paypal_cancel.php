<?php
echo 'Hủy thanh toán';
?>